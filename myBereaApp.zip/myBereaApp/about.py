"""
[Table of Contents]

1. Import Statements
2. About Function

"""

####### Import Statements #######
# import all the modules needed for the app
# from modules import *
from app import *
from flask import render_template

#########

###### About Function ########
# The about function is a controller for the about.html page. It renders the template
@app.route('/about')
def about():
    return render_template('about.html')
