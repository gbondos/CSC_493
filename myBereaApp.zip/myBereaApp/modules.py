
from app import * # import Flask app
from models.Users import Users # The models contains the the database models for Users table
from models.Jobs import Jobs # The models contains the the database models for Jobs table
from login_required import * # Import the login_required 
from flask_wtf import FlaskForm # This is a Flask library  for Forms
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo, Length #All the
from flask import render_template, flash, redirect, url_for, session, request, logging
# render_template is to render html. It is a flask module
# flash is a flask notification
# redirect is to redirect users to a different html page
from wtforms import Form, StringField, BooleanField, TextAreaField, PasswordField, validators
# Flask wtforms is for flask forms
from passlib.hash import sha256_crypt
# A flask library that hash passwords
from functools import wraps
