'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. Add Articles Function

'''

from app import *
from modules import *
from flask import render_template
from data import dummy_Articles
List_Articles = dummy_Articles()
from models.Jobs import *
from login_required import *

@app.route('/jobs')
@is_logged_in
def jobs():
    query = Jobs.select().execute()
    if query:
        return render_template('jobs.html', jobs = query)
    else:
        msg = "No Jobs Found"
        return render_template('jobs.html', msg=msg)

@app.route('/job/<string:id>/')
@is_logged_in
def job(id):
    query = Jobs.get(id=id)
    return render_template('job.html', job = query)
