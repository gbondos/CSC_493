from modules import *

@app.route('/logout')
def logout():
    session.clear()
    flash("You are successfully logged out!", 'success')
    return redirect(url_for('index'))
