'''
[Table of Contents]

1. Import Statements
2. Logout Function

'''
from modules import *

@app.route('/logout')
def logout():
    """
    The function to logout users
    """

    session.clear() #Deletes user session
    flash("You are successfully logged out!", 'success')
    return redirect(url_for('index'))
