from app import *
from modules import *
# from flask import render_template


@app.route('/testing')
def testing():
    return render_template('testing.html')
