"""
The
[Table of Contents]

1. Import Statements
2. About Function


"""

from flask import Flask
# from flask_mail import Mail
app = Flask(__name__)

from models.config import * # Import configuration to database
from index import * # Import all functions from index.py
from about import * # Import all functions from about.py
from jobs import * # Import all functions from jobs.py
from login import * # Import all functions from login.py
from signup import * # Import all functions from signup.py
from dashboard import * # Import all functions from dashboard.py
from logout import * # Import all functions from logout.py
from add_jobs import * # Import all functions from add_jobs.py
from edit_job import * # Import all functions from edit_job.py
from delete_job import * # Import all functions from delete_job.py
from flask_email import * # Import all functions from flask_mail.py
from testing import * # Import all functions from testing.py


if __name__ == '__main__':
    app.secret_key = 'Secret key' # This is a secret key for users session. Should not be used in production
    app.run(debug = True)
