from flask import Flask
# from flask_mail import Mail
app = Flask(__name__)

from models.config import * # Import configuration to database
from index import *
from about import *
from jobs import *
from login import *
from signup import *
from dashboard import *
from logout import *
from add_jobs import *
from edit_job import *
from delete_job import *
from flask_email import *
from testing import *


if __name__ == '__main__':
    app.secret_key = 'Secret key'
    app.run(debug = True)
