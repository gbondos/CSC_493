from flask import render_template
from models.Users import *
from models.Jobs import *
from login_required import *
from app import *



@app.route("/dashboard")
@is_logged_in
def dashboard():
    query = Jobs.select().execute()
    if query:
        return render_template('dashboard.html', jobs = query)
    else:
        msg = "No articles Found"
        return render_template('dashboard.html', msg=msg)
