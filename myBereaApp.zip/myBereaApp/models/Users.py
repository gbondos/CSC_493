from models.config import *
# Since peewee is an ORM, models have to be created for the jobs
# Created Users model for the database

class Users(DynamicModel):
    id = PrimaryKeyField()
    name = CharField()
    email = CharField()
    username = CharField()
    password = CharField()
    register_date = DateTimeField()
