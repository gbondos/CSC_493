from models.config import *

class Users(DynamicModel):
    id = PrimaryKeyField()
    name = CharField()
    email = CharField()
    username = CharField()
    password = CharField()
    register_date = DateTimeField()
    
