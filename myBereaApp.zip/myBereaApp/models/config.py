from peewee import *
DB = MySQLDatabase("myflaskapp", host="localhost", user="flask", passwd="flask2018")
# DB = MySQLDatabase("gbondos", port = 3306, host="tango.berea.edu", user="gbondos", passwd="Millionaire@at2019")

class DynamicModel(Model):
    class Meta:
        database = DB
