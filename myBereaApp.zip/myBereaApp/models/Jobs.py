from models.config import *

class Jobs(DynamicModel):
    id = PrimaryKeyField()
    title = CharField()
    author = CharField()
    body = CharField()
    create_date = DateTimeField()
