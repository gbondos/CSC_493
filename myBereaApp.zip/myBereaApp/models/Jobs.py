from models.config import *
# Model class for Jobs in the database
# Since peewee is an ORM, models have to be created for the jobs
class Jobs(DynamicModel):
    id = PrimaryKeyField()
    title = CharField()
    author = CharField()
    body = CharField()
    create_date = DateTimeField()
