from modules import *
from models.Jobs import Jobs
from flask import session
from login_required import *


class JobForm(Form):
    title = StringField('Title', validators = [DataRequired(), Length(min = 1, max = 250)])
    body = TextAreaField('Body', validators = [DataRequired(), Length(min=4)])

@app.route("/add_jobs", methods=['GET', 'POST'])
@is_logged_in
def add_articles():
    job = Jobs()
    form = JobForm(request.form)
    if request.method == 'POST' and form.validate():
        job.title = form.title.data
        job.body = form.body.data
        job.author = session['name']
        job.save()
        flash('You have successfully added a job to the dashboard.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_jobs.html', form = form)
