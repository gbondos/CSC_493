from models.Users import *
from app import *
from modules import *

@app.route("/")
def index():
    user = Users.get(id=1)
    return render_template('index.html', user = user)
