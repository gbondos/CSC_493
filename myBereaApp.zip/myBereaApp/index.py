'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. Add Articles Function

'''
from models.Users import *
from app import *
from modules import *

@app.route("/")
def index():
    """
    This is a controller function for the index.html page
    """
    user = Users.get(id=1)
    return render_template('index.html', user = user)
