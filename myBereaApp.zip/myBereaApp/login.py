'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. Add Articles Function

'''

from modules import *
# from flask_wtf import FlaskForm

class LoginForm(Form):
    email = StringField('Email Address', validators = [DataRequired(), Length(min=6, max=50), Email()])
    password = PasswordField('Enter Password', validators = [DataRequired()])

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm(request.form)
    if request.method == 'POST' and form.validate():
        # email_address = request.form['email']
        # password_candidate = request.form['password']
        email_address = form.email.data
        password_candidate = form.password.data

        try:
            person = Users.get(Users.email == email_address)
            password = person.password
            name = person.name
            if sha256_crypt.verify(password_candidate, password):
                session['logged_in'] = True
                session['email_address'] = email_address
                session['name'] = name

                flash('You are now logged into your account!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash("Invalid email address or password.", "warning")
                return render_template('login.html', form = form)
        except Users.DoesNotExist:
            # app.logger.info("No email address exists")
            flash("Invalid email address or passwords.", "warning")
            return render_template('login.html', form = form)


    return render_template('login.html', form = form)

# Check if user logged in
# def is_logged_in(f):
#     @wraps(f)
#     def wrap(*args, **kwargs):
#         if 'logged_in' in session:
#             return f(*args, **kwargs)
#         else:
#             flash('Unauthorized, Please login', 'danger')
#             return redirect(url_for('login'))
#     return wrap

# Logout
# @app.route('/logout')
# @is_logged_in
# def logout():
#     session.clear()
#     flash('You are now logged out', 'success')
#     return redirect(url_for('login'))
