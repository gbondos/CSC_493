'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. edit_job Function

'''
########### Import Statements ############
from modules import *
from models.Jobs import Jobs
from flask import session
from login_required import *


class JobForm(Form):
    """
    Uses wtform for form validation
    """
    title = StringField('Title', validators = [DataRequired(), Length(min = 1, max = 250)])
    body = TextAreaField('Body', validators = [DataRequired(), Length(min=4)])

@app.route("/edit_job/<string:mid>", methods=['GET', 'POST'])
@is_logged_in # Log in decorator. Grant access to only users that are logged in.
def edit_job(mid):
    """
    This function gets the users data from the form and edit the file
    """
    job = Jobs() # object of the job class
    form = JobForm(request.form)
    query = job.get(id = mid)
    specific_id = query.id
    form.title.data = query.title
    form.body.data = query.body

    if request.method == 'POST' and form.validate():
        update_title = request.form['title']
        update_body = request.form['body']
        updated = Jobs.get(id = mid)
        updated.title = update_title
        updated.body = update_body
        updated.save()
        # article.update(title = update_title).where(id = specific_id).execute()
        flash('You have successfully updated a Job.', 'success') #Flash message of success
        return redirect(url_for('dashboard'))
    return render_template('edit_job.html', form = form)
