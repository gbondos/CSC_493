'''
[Table of Contents]

1. Import Statements
2. JobForm class
3. Add Articles Function

'''

from flask import render_template
from models.Users import *
from models.Jobs import *
from login_required import *
from app import *


@app.route('/delete_job/<string:id>', methods=['POST']) # POST request
@is_logged_in # This decorator is to check if a user is logged in
def delete_job(id):
    # Gets the job id and deletes the user
    deleted = Jobs.get(id = id)
    deleted.delete_instance()
    flash("Sucessfully deleted ", 'success') # Send a message to show successful deletion
    return redirect(url_for('dashboard'))
