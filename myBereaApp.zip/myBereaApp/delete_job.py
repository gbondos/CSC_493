from flask import render_template
from models.Users import *
from models.Jobs import *
from login_required import *
from app import *


@app.route('/delete_job/<string:id>', methods=['POST'])
@is_logged_in
def delete_job(id):
    deleted = Jobs.get(id = id)
    deleted.delete_instance()
    flash("Sucessfully deleted ", 'success')
    return redirect(url_for('dashboard'))
